import os
import subprocess
import re
import socket
import requests

# Define colors for console output
BLACK = "\033[0;30m"
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[0;33m"
BLUE = "\033[0;34m"
MAGENTA = "\033[0;35m"
CYAN = "\033[0;36m"
LIGHT_GRAY = "\033[0;37m"
DARK_GRAY = "\033[1;30m"
LIGHT_RED = "\033[1;31m"
LIGHT_GREEN = "\033[1;32m"
LIGHT_YELLOW = "\033[1;33m"
LIGHT_BLUE = "\033[1;34m"
LIGHT_MAGENTA = "\033[1;35m"
LIGHT_CYAN = "\033[1;36m"
WHITE = "\033[1;37m"
RESET = "\033[0m"
NORMAL = "\033[0m"

def nmap(selected_commandes,output,domain):
    folder_name = f"vulnerabilty detected {domain}"
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    with open(f"{directory}/{output}", "r") as f:
        text=f.readlines()
        for com in selected_commandes:
            if com==1:
                for line in text:
                    line = line.rstrip('\n')
                    command = f"nmap -A -script vuln -oX {directory}/{folder_name}/{line}.xml {line}"
                    command1=f"xsltproc {directory}/{folder_name}/{line}.xml -o {directory}/{folder_name}/{line}.html "
                    result1 = subprocess.check_output(command , shell=True, universal_newlines=True)
                    result2 = subprocess.check_output(command1 , shell=True, universal_newlines=True)
                    xml=f"{directory}/{folder_name}/{line}.xml"
                    os.remove(xml)
            if com==2:
                    command=f"nikto -h {domain} -output /{directory}/nikto.txt"


def acceblibe(domain):
    with open(f'{directory}/Accebible_{domain}.txt', 'w') as file:
        with open(f"{directory}/httprobe_{domain}.txt", 'r') as f:
            sous_domaines = f.readlines()
            # Boucle à travers chaque sous-domaine
            for sous_domaine in sous_domaines:
                # Supprimer les espaces et les sauts de ligne
                sous_domaine = sous_domaine.strip()
                # Vérifier si le sous-domaine est accessible
                try:
                    response = requests.get(f'{sous_domaine}', timeout=5)
                    if response.status_code == 200:
                        file.write(f'\n{sous_domaine} est accessible\n')
                    else:
                        file.write(f'\n{sous_domaine} est inaccessible \n')
                except requests.exceptions.RequestException as e:
                    file.write(f'\n{sous_domaine} est inaccessible \n ')
        with open(f'{directory}/Subdomains_{domain}.txt', 'r') as fi:
            sous_domaines = fi.readlines()
            # Boucle à travers chaque sous-domaine
            for sous_domaine in sous_domaines:
                # Supprimer les espaces et les sauts de ligne
                sous_domaine = sous_domaine.strip()
                # Vérifier si le sous-domaine est accessible
                try:
                    response = requests.get(f'https://{sous_domaine}', timeout=5)
                    if response.status_code == 200:
                        file.write(f'\n{sous_domaine} est accessible\n')
                    else:
                        file.write(f'\n{sous_domaine} est inaccessible \n')
                except requests.exceptions.RequestException as e:
                    file.write(f'\n{sous_domaine} est inaccessible \n ')


def ip4v(target):
    with open(f"{directory}/Subdomains_{domain}.txt", 'r') as f:
        with open(f"{directory}/ip_{domain}.txt", 'w') as f2:
            with open(f"{directory}/ip2_{domain}.txt", 'w') as f3:
                # Parcourir chaque ligne dans le fichier
                for line in f:
                    # Supprimer les caractères de fin de ligne
                    line = line.strip()
                    # Résoudre l'adresse IP pour le sous-domaine
                    try:
                            ip = socket.gethostbyname(line)
                            # Vérifier si l'adresse IP est une adresse IPv4
                            if ip.count('.') == 3:
                                    # Afficher l'adresse IP
                                f3.write(f"\n{ip}\n")
                                f2.write(f"\n{line} has IP address {ip}\n")
                    except socket.gaierror:
                                # Gérer l'erreur si le sous-domaine ne peut pas être résolu
                                f2.write(f"\nCould not resolve {line}\n")

def subdomains(selected_commandes, domain):
    with open(f"{directory}/subdomains_{domain}.txt", "w") as f:
        for com in selected_commandes:
            if com == 1:
                print(f"{LIGHT_CYAN} dnsrecon")
                commanddns=f"dnsrecon -d {domain}"
                resultdns = subprocess.check_output(commanddns, shell=True, universal_newlines=True)
                f.write("------------------------------dnsrecon------------------------------------------------------\n")
                for line in resultdns.splitlines():
                    if domain in line:
                        f.write(line + "\n")
            if com == 2:
                print(f"{LIGHT_CYAN} sublist3r")
                commandsublist3r=f"sublist3r -d {domain}"
                resultsub=subprocess.check_output(commandsublist3r, shell=True, universal_newlines=True)
                f.write("----------------------------------sublist3r--------------------------------------------------\n")
                for line in resultsub.splitlines():
                    # line = line.partition("m")[2]
                    if domain in line:
                        f.write(line + "\n")
            if com == 3:
                print(f"{LIGHT_CYAN} fierce")
                commandfierce =f"fierce --domain {domain}"
                resultsfierce=subprocess.check_output(commandfierce, shell=True, universal_newlines=True)
                f.write("-----------------------------fierce-------------------------------------------------------\n")
                for line in resultsfierce.splitlines():
                    if domain in line:
                        f.write(line + "\n")
            if com == 4:
                print(f"{LIGHT_CYAN} knockpy")
                commandknocky =f"knockpy {domain}"
                resultsknocky=subprocess.check_output(commandknocky , shell=True, universal_newlines=True)
                f.write("-----------------------------knocky------------------------------------------------------\n")
                for line in resultsknocky.splitlines():
                    if domain in line:
                        if "(ctrl+c)" not in line:
                            match = re.match(r'^([3-4][0-9])m', line)
                            f.write(line + "\n")
                            f.write("\n")
    # Define a regular expression pattern to match subdomains
    subdomain_pattern = r'(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?!\.)'
    # Open the text file for reading
    with open(f"{directory}/subdomains_{domain}.txt", 'r') as file:
        # Read the contents of the file
        contents = file.read()
        # Find all matches of the subdomain pattern in the contents
        subdomains = set(re.findall(subdomain_pattern, contents))
        with open(f"{directory}/Subdomains_{domain}.txt", 'w') as f1:
            # Parcourir chaque ligne des résultats
            f1.write('\n'.join(subdomains))
    print(f"{YELLOW} file done")

def httprobe(directory, domain):
    with open(f"{directory}/httprobe_{domain}.txt", "w") as f:
        command = f" cat {directory}/Subdomains_{domain}.txt | httprobe"
        result = subprocess.check_output(command, shell=True, universal_newlines=True)
        f.write(result)


# Directory search ===============================================================================================
def fuzzing(output,target):
    # print message to user
    print(f"\n{GREEN}[+] Directory search {NORMAL}\n")
    print(f"{NORMAL}{CYAN}Searching ...{NORMAL}\n\n")
#200,204,301,302,307,401,403,405,500
    with open(f"{directory}/{output}", 'r') as f:
        text=f.readlines()
        # Parcourir chaque ligne dans le fichier
        for line in text:
            # Remove newline character from end of line
            line = line.rstrip('\n')
            # Les commandes des FUZZING
            commandffuf = f"ffuf -c -w /usr/share/dirb/wordlists/big.txt -u {line}/FUZZ"
            # # L'execution des commandes
            result_bytes = subprocess.check_output(commandffuf, shell=True)
            result1 = result_bytes.decode('utf-8', errors='replace')
            with open(f'{directory}/Fuzzing_{target}.txt', 'w') as file:
                file.write(result1)
            with open(f'{directory}/Fuzzing_{target}.txt', 'r') as file:
                with open(f'{directory}/Fuzzing_inaccessible_url_{target}.txt', 'w') as f1:
                    with open(f'{directory}/Fuzzing_accessible_url_{target}.txt', 'w') as f2:
                        # for line in result1.split('\n') :
                        for line1 in file:
                            # Extraire le nom de fichier à partir de la chaîne de texte en utilisant une expression régulière
                            string= line1.partition("m")[2]
                            if "200" in string or "403" or "301" in string:
                                new_string = string.split("[")[0]
                                url = f"{line}/" + new_string
                                f1.write(f'\n{url} est inaccessible \n')
                            else :
                                new_string = string.split("[")[0]
                                if new_string!="":
                                    url = f"{line}/" + new_string
                                    f2.write(f'\n{url} est accessible \n')
if __name__ == '__main__':
    domain = input(f"{BLUE}Please enter a domain name to scan: {BLUE}")
    while not domain:
        domain = input(f"{BLUE}Please enter a domain name to scan: {BLUE}")
    directory = input("Please enter a directory: ")
    while not directory:
        directory = input("Please enter a directory: ")
    an_folder =input("do you want to create a folder in your directory to put your output or you want to put it in directory answer with [yes/no] : ")
    if an_folder == "yes" :
        folder_name= input("name of your folder : ")
        if not os.path.exists(folder_name):
            os.makedirs(folder_name)
        directory=directory+"/"+folder_name
    elif an_folder == "no" :
        directory = directory
    else :
        an_folder = input("do you want to create a folder in your directory to put your output or you want to put it in directory answer with [yes/no] : ")

    print("Available functions")
    print("1.Subdomain Enumeration")
    print("2.Informations sur URLs")
    print("3.Nmap")
    print("4.Fuzzing")
    selected_functions = input("\nEnter comma-separated function numbers to run (e.g. 1,2,3), or type 'all' to select both all: ")

    if selected_functions == "all":
        subdomains(directory,domain)

    else:
        selected_functions = [int(x.strip()) for x in selected_functions.split(",")]
        for func in selected_functions:
            if func == 1:
                print("Subdomain Enumeration")
                print("Another important element of reconnaissance, both passive and active, is the process of identifying company subdomains.")
                print("Available commandes")
                print("1.dnsrecon")
                print("2.sublist3r")
                print("3.fierce")
                print("4.Knocky")
                selected_commandes=input("Entrez les commandes :")
                selected_commandes = [int(x.strip()) for x in selected_commandes.split(",")]
                subdomains(selected_commandes, domain)
            if func == 2:
                print("Infos for domain")
                httprobe(directory, domain)
                acceblibe(domain)
                ip4v(domain)
            if func == 3:
                output=input("entrez votre output name")
                nmap(output)
            if func == 4:
                output_fuzzing=input("entrez votre output name")
                fuzzing(output_fuzzing,domain)

