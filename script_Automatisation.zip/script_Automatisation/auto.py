import time
import winsound

# Set the duration of the timer in seconds
timer_duration = 240

# Start the timer
start_time = time.time()

# Wait for the timer to expire
while time.time() < start_time + timer_duration:
    pass

# Play the alert sound
winsound.PlaySound("SystemAsterisk", winsound.SND_ALIAS)
